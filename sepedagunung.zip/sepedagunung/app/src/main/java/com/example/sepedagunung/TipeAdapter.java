package com.example.sepedagunung;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TipeAdapter extends Recyclerview.Adapter<TipeAdapter.Tipeviewholder> {
    private Context context;
    private ArrayList<Tipe> tipes;

    public TipeAdapter(Context mcontext, ArrayList<Tipe> tipesepedagunung){
        context=mcontext;
        tipes=tipesepedagunung;


    }
    @NonNull
    @Override
    public Tipeviewholder onCreateViewholder(@NonNull ViewGroup parent, int viewType){
        View v = LayoutInflater.from(context).inflate(R.layout.item_tipe,parent, false);

        return new Tipeviewholder(v);
    }

    @Override
    public void onBindViewholder(@NonNull Tipeviewholder holder, int position){
        Tipe tipebaru=tipes.get(position);
        String gambarbaru = tipebaru.getGambar();
        String harga= tipebaru.getHarga();
        String nama= tipebaru.getNama();

        holder.tvnamadata.setText(nama);
        holder.tvhargadata.setText(harga);
     Glide
           .with(context)
           .load(gambarbaru)
           .centerCrop()
           .into(holder.imdata);

    }

    @Override
    public int getItemCount(){
        return tipes.size()
    }

    public class Tipeviewholder extends RecyclerView.viewholder {
        public ImageView imdata;
        public TextView tvhargadata;
        public TextView tvnamadata;

        public Tipeviewholder(@NonNull View itemView){
            super(itemView);
            indata= itemView.findViewById(R.id.img_tipe);
            tvhargadata=itemView.findViewById(R.id.tv_harga);
            tvnamadata=itemView.findViewById(R.id.tv_nama);



        }
    }



}
