package com.example.sepedagunung;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.net.sip.SipSession;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TipeAdapter tipeAdapter;
    private RecyclerView recyclerView;
    private ArrayList<Tipe> Tipes;
    int jumdata;
    private RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.rv_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Tipes = new ArrayList<>();
        requestQueue = Volley.newRequestQueue(this);
        perseJSON();
    }
    private void perseJSON(){
        String url= "http://localhost:81/sepedagunung/koneksi.php"
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET,url,null,
                new Response.Listener<>JSONArray>(){
                    @Override
                    public vold onResponse(JSONArray response){
                        jumdata=response.length();
                        try {
                            for (int i=0; i<jumdata;i++){
                                JSONObject data = response.getJSONObject(i)
                                string gambartipe=data.getString( name"gambar");
                                String namatipe=data.getString(name "nama");
                                String hargatipr=data.getString(name"harga");
                                Tipes.add(new Tipe(namatipe,hargatipe,gambartipe))
                            }
                            tipeAdapter = new TipeAdapter(MainActivity.this,Tipes);
                            recyclerView.setAdapter(tipeAdapter);
                        }catch (JSONException = e){
                            e.printStackTrace();
                        }
                    }
                 },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                error.printStackTrace();
            }
        }
    }

    RequestQueue.add(request);
    }
}
